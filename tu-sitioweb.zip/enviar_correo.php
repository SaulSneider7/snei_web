<?php
header('Content-Type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer/Exception.php';
require './PHPMailer/PHPMailer.php';
require './PHPMailer/SMTP.php';

// Honeypot
if (!empty($_POST['empresa'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Error de validación.'
    ]);
    exit;
}

// Sanitizar datos
$nombre   = trim(strip_tags($_POST['nombre'] ?? ''));
$email    = trim(filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL));
$telefono = trim(strip_tags($_POST['telefono'] ?? ''));
$mensaje  = trim(strip_tags($_POST['mensaje'] ?? ''));


// Validaciones básicas
if ($nombre === '' || $email === '' || $mensaje === '') {
    echo json_encode([
        'success' => false,
        'message' => 'Completa todos los campos obligatorios.'
    ]);
    exit;
}

// Validar email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'success' => false,
        'message' => 'Correo electrónico no válido.'
    ]);
    exit;
}




$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 2;                                       //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'mail.tu-sitioweb.com';                 //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'contacto@tu-sitioweb.com';             //SMTP username
    $mail->Password   = 'ynYMcr=_(XAo';                         //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('contacto@tu-sitioweb.com', 'Formulario Web');
    $mail->addAddress('contacto@tu-sitioweb.com');              //Add a recipient
    $mail->addAddress($email, $nombre);                     //Name is optional
    //Reply To
    $mail->addReplyTo($email, $nombre);

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Nuevo contacto desde el Sitio Web';
    $mail->Body = "
        <h2>Nuevo mensaje recibido</h2>
        <p><strong>Nombre:</strong> {$nombre}</p>
        <p><strong>Email:</strong> {$email}</p>
        <p><strong>Teléfono:</strong> {$telefono}</p>
        <hr>
        <p>{$mensaje}</p>
    ";


    $mail->AltBody = "
        Nombre: {$nombre}
        Email: {$email}
        Teléfono: {$telefono}

        Mensaje:
        {$mensaje}
    ";

    $mail->send();
    echo json_encode([
        'success' => true,
        'message' => 'Mensaje enviado correctamente. Te contactaremos en menos de 24 horas.'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Tenemos problemas técnicos en este momento. Inténtalo más tarde.'
    ]);
}